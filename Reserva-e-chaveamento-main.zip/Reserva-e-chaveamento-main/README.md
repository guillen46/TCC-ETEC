# Reserva-e-chaveamento
# Olá, esse código aqui é meu projeto de TCC, é um código bem completo sobre reserva de quadra 
# e chaveamento de campeonato
